---
name: i-canhandle-this
description: Create original, polished presentations in editable PPTX or offline HTML by combining layout, icon systems, data charts, imagery, and purposeful motion. Use for courseware, reports, proposals, academic talks, introductions, and visual redesigns even when no source template is present.
---

# 交给我吧（i canhandle this）

This skill is portable. The original G-drive collection is **not** a runtime dependency. A small, user-authorized library of eight native pages is bundled in `assets/native-pages/`; consult `references/native-page-library.md` before using it. The 23-folder study was also converted into reusable decisions in `references/`. Do not depend on the original source paths at runtime.

## Intake and decision

1. Determine the audience, presentation setting, purpose, desired duration/slide count, content, delivery format (PPTX, HTML, or both), and editability expectations. If missing, infer a conservative default and state it briefly. Ask only if the missing choice changes the result materially.
2. Convert the material into a message arc before drawing slides: opening promise → context/problem → 2–4 idea blocks → evidence/demo/exercise → takeaway/action. For a course, add learning objectives, concept explanation, worked example, learner interaction, recap. Do not force a business-report outline onto teaching.
3. Assign each slide one **job** and one sentence-level takeaway. Pick layouts from `references/page-patterns.md` according to information shape, not by alternating arbitrary templates.
4. Choose a base grammar from `references/style-catalog.md` using audience, emotional tone, and content density. Combine at most two compatible grammars. Set palette, type pairing, grid, image treatment, icon language, and recurring motif before slide generation.
   For a multi-slide deck, read `references/deck-cohesion-study.md` and borrow functions across template families without importing conflicting skins.
5. Use `references/design-grammar.md` for geometry, typographic hierarchy, and pacing. When the content involves processes, categories, numbers, or data, read `references/icon-chart-motion.md` to select the right visual relationship and animation sequence. Use `references/motion.md` for format-specific motion decisions.
6. Before rendering, complete the **visual carrier** plan in `references/visual-completion.md`: every slide needs a background role, a primary visual carrier, and a content-to-visual mapping. A sound outline with uniform pale backgrounds and text columns is not an acceptable finished deck.
7. When a bundled native page matches the slide's job, start from a **copy** of its PPTX and replace content in-place. Preserve its composition, element relationships, and animation unless there is a reason to change them. Use the catalog's suitability and cleanup notes; these are source pages, not automatically finished templates.

## Production rules

- Prefer native editable text, shapes, and charts in PPTX. In HTML, keep the deck self-contained/offline, responsive to a 16:9 stage, keyboard-navigable, and printable/exportable where feasible. If both formats are requested, use one shared design specification and check parity.
- Treat every icon, chart, and motion effect as part of the explanation. Icons should encode actions or categories consistently; real data charts must retain verified values, units, denominator, period, and source. Do not turn template filler numbers into claims. Animation should reveal the speaker's reasoning while leaving a complete static state.
- Build slides from content outward. A slide is not finished when the placeholders are filled; rewrite, split, or omit material to preserve reading hierarchy.
- Use the four focused recipes in `references/focus-collections.md` when the brief calls for a stronger design: icon/infographic systems, fashion-editorial art direction, creative motif systems, and instructor-led courseware. Prefer a small coherent element vocabulary over adding unrelated decoration.
- Use genuine user-provided or licensed visual assets. Never transfer previews' QR codes, advertising overlays, watermarks, placeholder dates/names, random logos, stock claims, or decorative English filler.
- For a user-authorized template reuse request, direct reuse of a bundled native page is allowed. Remove source branding, placeholder copy, inappropriate photos, and irrelevant visual claims before handoff. When no suitable native page exists, build an original slide using the documented grammar; do not force a mismatch.
- If source is an image, distinguish visual reconstruction from editable reconstruction. Explain what can be made native and what remains raster; do not promise perfect recovery from pixels.
- For animation, provide a static fallback and honor reduced-motion preference in HTML. Avoid autoplay motion that shakes, distracts, or conceals important content.

## Internal pre-handoff checks

Check every slide for: claim accuracy and source handling; legibility at presentation distance; consistent alignment and spacing; intentional contrast; text overflow and crop; chart labels and units; image rights/provenance; motion that adds meaning; no source debris; editable elements as promised. Render or inspect the output before claiming completion. User acceptance is a separate stage—do not impersonate the user's validation.

## Reference routing

- Core visual and information design: `references/design-grammar.md`
- Style selection and combination: `references/style-catalog.md`
- Slide jobs, content-to-layout mapping: `references/page-patterns.md`
- PPTX/HTML animation and static alternatives: `references/motion.md`
- Evidence, sample coverage, and limits of this study: `references/study-notes.md`
- Required visual-carrier plan and visual QA: `references/visual-completion.md`
- Focused icon, fashion, creative, and training recipes: `references/focus-collections.md`
- Bundled native pages, provenance, fit, cleanup, and limits: `references/native-page-library.md`
- Whole-deck rhythm, safe mixing, and motion decisions from eight additional samples: `references/deck-cohesion-study.md`
- Integrated icon, data-chart, and animation decisions from five further samples: `references/icon-chart-motion.md`
