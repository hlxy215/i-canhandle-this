# Visual completion contract

The first user challenge deck had a reasonable content structure but appeared plain: many pages repeated a light background, a rule, and text columns. Treat this as a known failure case. Before production, write a brief slide-level specification with these fields: **job, takeaway, visual carrier, background role, element system, layout, interaction/motion if needed**. Do not leave visual carrier or background role blank.

## Three scales of design

1. **Deck signature:** palette with functional roles, type pairing, grid, image treatment, and one recurring motif. Consistency comes from these constraints, not from identical page layouts.
2. **Page carrier:** one meaningful focal device. Options include a documentary photo, a subject-derived illustration/metaphor, a process map, relational infographic, evidence chart, oversized number/statement, or a deliberately designed typographic composition. It should make the slide's claim easier to grasp.
3. **Local elements:** icons, connectors, labels, number chips, frames, callouts, arrows, and micro-patterns. They must belong to one visual family and clarify hierarchy or relationships. More items do not automatically improve a slide.

## Background and pacing

Pick a background *role* for every page: immersive full-bleed opening/section; split color field; photographic field with legible scrim; light reading field; diagram canvas; gentle texture/pattern; or intentional empty field for a single strong claim. Vary the role with the content. Avoid runs of three or more near-identical text-on-white slides unless they are deliberately paired for comparison.

For a medium deck, plan a rhythm: visual opening → navigational/overview page → explanatory pages with distinct carriers → contrasting case or evidence page → participatory or reflective pause → synthesis. Quiet pages are valuable, but quiet is not unfinished. A quiet page still needs precise scale, crop, placement, and tension.

## Element selection

- Map the information shape before selecting a graphic: sequence → steps/path; cycle → loop; hierarchy → tree/stack; comparison → paired fields; system → node/link; quantity → chart; case → image plus annotation. Do not put a cycle diagram on unrelated prose.
- Create one icon family per deck: outline **or** filled; consistent stroke, corner radius, visual weight, optical size, and 1–2 functional colors. Pair icons with short labels and relational geometry; an icon row by itself is rarely the whole composition.
- Reuse a motif by changing scale, crop, or position across cover, section, and content pages. Reuse its logic, not the exact same stamp at every corner.
- Use native vector shapes where editability matters. Use original or properly licensed photos/illustrations. Do not extract commercial template artwork into the portable skill.

## Visual QA gate

Inspect a contact sheet and each slide at presentation size. Ask: Can the main point be inferred in three seconds? Is there a dominant visual carrier, not just a title? Does the background support it? Are important elements consistent in style? Is the density appropriate to the page's job? Does the deck have at least a few genuinely distinct page compositions while retaining one identity? If it looks like a document pasted onto slides, revise the visual plan before handoff.
