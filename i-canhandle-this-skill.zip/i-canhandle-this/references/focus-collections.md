# Four focused visual grammars

These rules distill a focused study of `22-图标系列`, `20-时尚风格`, `16-创意风格`, and `11-培训课件`. They are portable recipes, not source-template copies. Choose according to audience and content; do not blindly blend all four.

## 1. Icon series: an information-geometry toolkit

The strongest examples are not loose pictograms. They combine a consistent icon family with numerals, connecting lines, color-coded modules, and spatial relationships. Build the diagram **from the claim**:

| Message | Suitable geometry | Element role |
| --- | --- | --- |
| Stages or procedure | rising steps, path, connected stations | icon marks action, number gives order |
| Three to five parallel ideas | aligned modules or radial clusters | icon helps scanning, equal scale means equal rank |
| Whole and parts | center plus satellites, tree, nested field | links and spacing explain membership |
| Feedback or recurrence | loop with a clear entry/exit | arrows show direction, not ornament |
| Before/after | matched paired compositions | same scale enables comparison |

Select one stroke/fill style and constrain hue: base neutral, one main color, one contrast color, optional semantic warning. Let one information structure dominate the page. Older glossy spheres, heavy shadows, random 3D people, and rainbow charts are not default modern styling; borrow their topology only. Isometric objects work when an object metaphor explains the concept, not as filler.

## 2. Fashion style: editorial composition

Fashion examples derive their sophistication from **art direction**: intentional photography, unusual but stable crop, reserved palette, typography at varied scale, and asymmetrical balance. Start with an image or desired atmosphere, then pull one or two colors from it. Use light/dark neutrals as the field and one accent deliberately. Strong observed variations included forest-green botanical editorial, brick-red and warm-white portrait layouts, warm mauve/terracotta with soft organic color fields, and bright cyan on white; do not reduce “fashion” to a single pastel palette.

Practical recipe: set a strong image-to-text ratio, establish a margin grid, place one large title, one small editorial label, and one controlled accent. Across pages alternate photo-led, text-led, and mixed compositions. Crop images to support the text's negative space. A frame or color block may partially overlap a photo, but keep the key subject unobscured and body copy readable. For Chinese, prioritize legible CJK type; a decorative Latin serif should not force a mismatched Chinese body font. Use translucent layers only when contrast survives projection.

Avoid using fashion portraits in unrelated institutional training. Transfer the spacing, palette discipline, crop logic, and typographic hierarchy to relevant authentic images instead.

## 3. Creative style: one governing visual metaphor

The most memorable sets use a clear art device: a monochrome bird/cage line system, music notes orbiting a central disk, a hand-drawn lightbulb, a low-poly rain cloud, or a diagonal cut through photography. Their artistic character comes from repeating and transforming that device, not scattering many motifs.

Write a one-sentence concept before drawing: “This deck explains X through Y.” Map the motif to the topic and to at least three page jobs: cover hero, chapter marker, and an explanatory or reflective page. For example, a course on identifying problems may use a spotlight/light metaphor; the concept page can show what is illuminated versus hidden. Reserve large-scale imagery for covers/sections; simplify it on dense information pages. Break a grid on purpose once in a page, then provide a stable reading path.

Filter out effects that age poorly or conflict with audience: neon glows, scattered clip art, intense gradients, decorative 3D, or childish cartoon figures for adult topics. Art direction must never make labels small or diagrams ambiguous.

## 4. Training courseware: visual pedagogy, not a report template

Strong courseware gives the learner orientation and something to *do*: a vivid subject-relevant opening; numbered modules; an explanation diagram; a concrete case; an activity prompt; and a recap/transfer page. Some samples use an authentic scene or topic-specific metaphor (meeting notes for meeting practice, billiards for goals, a tree for growth). Reuse that metaphor where it teaches, not on every content page.

For each concept block, plan a teaching sequence: **question or situation → concise model → worked example → learner application → takeaway**. Use chapter openers to change pace. Within content pages, alternate diagram-led, case-photo-led, and practice-led formats. Repeat navigation markers and type hierarchy, but vary the dominant visual carrier. Make a facilitator version with notes or speaker prompts when requested.

Much of the training source collection is older corporate design: dense paragraphs, blue/red rails, glossy 3D people, stock handshake photos. Keep the useful teaching structure and navigation; modernize the visual execution. For sensitive themes, use calm, respectful imagery and avoid alarmist red or infantilizing visuals.

## Combining the four

When a user requests an engaging professional course deck, start with the training sequence, borrow icon-series information geometry for models, use fashion editorial rules for image/color/type, and add **one** creative metaphor as a deck signature. They play different roles and therefore can coexist. Do not reproduce four template styles page by page.
