# Source study, scope, and provenance

## Collection

The local source at study time was `G:\2652-1 通用PPT`. It contained 23 numbered category folders (`01`–`23`), plus `00-详情展示` and a small extras folder. A directory count showed 1,329 PPT/PPTX files in the 23 numbered folders and 83 in `00`; those 1,412 presentation files had matching JPG previews in their folders. The image previews are commercial-style collage sheets, frequently carrying QR codes, sales text, and watermark overlays. Those overlays are not design assets.

## What was actually inspected

- Visually inspected the `#1` collage preview across each of the 23 numbered categories and one `00` sample.
- Visually inspected additional previews from `01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 13, 14, 15, 16, 18, 19, 20`. Sample file numbers were commonly `13`; in `03` the second sample was `102`.
- Looked inside ten representative source PPTX files for slide and animation XML. All had transition/timing markup; several did not show visible object animation on most slides. Thus motion capability must be judged per slide, not inferred from a tag or category name.
- After the first user challenge exposed a plain-visual-output failure, performed a deeper pass over all 18 `22-图标系列` JPG collages and all 22 existing `11-培训课件` collages (`7` is absent; `23` exists). Studied representative previews across `20-时尚风格` (including 2, 8, 16, 24, 32, 40, 48, 56, 64, 73) and `16-创意风格` (including 3, 5, 8, 11, 16, 20, 24, 28, 32, 36, 40, 43). This is deeper coverage of the four priorities, not a claim that every fashion or creative file was individually opened.

This is a cross-category, qualitative design study, not a claim that all 1,412 decks were individually analyzed. It supports a portable first design grammar; user-run challenge cases will determine which patterns still need refinement.

## Transferable observations

- Category names mix purpose (`工作汇报`, `开题报告`, `企业宣传`) with appearance (`极简风格`, `莫兰迪PPT`, `时尚风格`) and artifact type (`图标系列`, `图表风格`). They should not become one menu of mutually exclusive styles.
- Within-category variation is substantial. `13-快闪风格` included both dark effects and plain blue/white word beats; `16-创意风格` included dimensional ribbon and monochrome hand-drawn city/sketch layouts; `10-欧美风` included a teal-and-gold watercolor editorial set. Learn principles, not a fixed mapping.
- Strong recurring ideas: a distinctive cover + quieter content pages; restrained color roles; a few repeated edge motifs; large display type; asymmetric imagery; diagrams mapped to information shape; section numerals. Weak recurring habits: tiny text, repetitive decorative headers, ornamental 3D charts, generic clip art, stock-photo filler, watermarks and QR overlays.
- Some decks are highly topic-specific (e.g. medical anatomy graduation defense, children's classroom illustration). Their information pattern may transfer, but the imagery and tone should not be generalized.
- Icon collection labels conceal a family of infographic systems: badge-plus-number, path, radial, cycle, process, comparison, map, and isometric object. The relation geometry is more transferable than any isolated icon. Fashion examples use photo crop, palette extraction, and editorial asymmetry. Creative examples rely on a governing motif and its transformation. Training examples add learner orientation and pedagogic sequence, though many literal design treatments are dated.

## Baseline challenge failure and correction

The first user challenge—university psychological screening course PPT—was structurally serviceable but visually too plain. Its repeated light backgrounds and text columns lacked layered backgrounds, substantive visual elements, and page-to-page rhythm. This is the behavioral baseline for the revised skill. `visual-completion.md` now makes page carrier/background planning mandatory, and `focus-collections.md` gives positive recipes for creating the missing visual layer. These instructions are a design hypothesis until the user evaluates a new deck; syntactic validation alone cannot establish aesthetic success.

## Boundaries and next validation

The draft now bundles eight selected native PPTX pages from four source decks, so those pages can be reused without the `G:` drive. It does not install fonts, establish image licenses, or magically internalize the source into model weights. The user will validate output quality later with unseen prompts, including both PPTX and HTML, and can request revision of the grammar based on concrete examples. A second focused comparison of eight complete contact sheets is recorded in `deck-cohesion-study.md`; that analysis has not yet produced additional bundled pages.
