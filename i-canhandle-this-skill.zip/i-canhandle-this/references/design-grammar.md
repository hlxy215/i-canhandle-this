# Transferable design grammar

## Work at four scales

1. **Deck** — a coherent visual identity and narrative rhythm. Repeat a few rules, not an identical frame everywhere.
2. **Slide** — one takeaway, one dominant element, one clear entry point. Let dense evidence pages differ from quiet transition pages.
3. **Component** — cards, callouts, photo windows, timelines, charts, icon groups, annotation lines. Each must encode a relationship, not merely fill space.
4. **Motion** — optional reveal sequence that follows the speaker's reasoning. Motion cannot rescue weak static hierarchy.

## Canvas, grid, and hierarchy

- Start from a 16:9 canvas unless requested otherwise. Protect an outer safe area around 5–7% of the slide. Work with a repeatable column grid; choose a strict grid for data, a flexible grid for editorial/photo-led work.
- Establish 3 levels of text: takeaway/title, section/content labels, explanatory body. Keep secondary labels visibly subordinate. In a typical projected 16:9 slide, titles often land around 28–44 pt, body around 18–24 pt, labels around 12–16 pt; adapt to room and density rather than mechanically enforcing numbers.
- Favor a Chinese sans-serif family with consistent available fallbacks for body text. Use a display serif or contrasting weight only when the visual grammar supports it; avoid decorative type for long Chinese paragraphs. Test punctuation and mixed Chinese/Latin numerals.
- Use proximity and alignment before adding boxes. White space is a functional separator. Never solve a dense slide by uniformly shrinking all text.
- A cover may be expressive. Subsequent evidence slides should progressively increase clarity and decrease decoration.

## Color roles

- Define background, primary text, secondary text, brand/semantic accent, and optional highlight. A useful default is a light neutral surface, dark legible ink, one main hue, and one restrained contrast hue.
- Evaluate contrast in real projected or screenshot conditions. Low-contrast muted palettes are appropriate for large decorative fields, not tiny labels.
- Use color semantically: categories, emphasis, positive/negative, sequence. Do not recolor each slide or each data series without meaning.
- If the brief asks for a color, vary saturation/value and introduce neutrals rather than repeating one flat swatch on every surface.

## Images and elements

- Crop images around the subject and narrative point; reserve negative space where text must sit. Never cover a face or focal object with a title bar by accident.
- Prefer one strong visual to a collage of weak stock photos. Match photographic color temperature across the deck.
- Extract elemental ideas rather than whole-slide compositions: an edge ribbon, framed photo, rounded photo window, hand-drawn contour, vertical micro-label, chapter numeral, thin rule, or annotation callout. Choose one or two recurring motifs.
- Keep icon stroke, corner radius, depth, and perspective consistent. Avoid mixing line icons, clip art, and photorealistic 3D on the same information tier.

## Data and diagrams

- Put the conclusion in the title; show the evidence beneath. Provide units, time range, baseline, source, and meaningful ordering.
- Use bars for category comparison, lines for trend, direct labels for a few values, tables for precise lookup, timelines for sequence, and diagrams for causal or structural relationships. Donuts are suitable only for a small number of parts of a whole; never invent percentages.
- Eliminate ornamental 3D and complex circles when a simple aligned chart communicates better. Highlight the comparison that supports the slide's sentence.

## Rhythm

- Alternate density deliberately: strong opening, brief orientation, medium-content explanation, one evidence-heavy slide when needed, breathing-space synthesis, actionable closing.
- Repeat composition family enough to feel unified, but change scale and image/text balance to avoid a monotonous template parade.
- A chapter divider is useful at a genuine conceptual transition, not before every small subsection.
