# Motion grammar

Motion should answer one of three questions: “What comes next?”, “What changed?”, or “Where should I look?” If it answers none, leave the slide static.

## Useful motion patterns

- **Reveal**: sequentially expose steps, chart annotations, or question → answer. Keep order aligned with speaking order.
- **Continuity**: move an object to its next state to show transformation or connection. Avoid teleporting a recurring shape when a simple dissolve is clearer.
- **Comparison**: introduce baseline and alternative without changing the chart scale; highlight the difference.
- **Emphasis**: one brief pulse/color shift to direct attention. Do not loop it.
- **Kinetic title**: short event opener with big text/number beats; treat as a special case, not a default content-slide style.

## Timing and restraint

Use consistent timings and easing families. Fast enough to maintain pace, slow enough to parse. Limit simultaneous motions; avoid shaking, constant floating, glitch, surprise zoom, and repeated bounce. If the viewer is likely to read during motion, motion is too busy.

## PPTX and HTML

- PPTX: prefer broadly compatible entrance/emphasis/transition effects and verify in a real renderer when possible. XML presence of `<p:timing>` alone is not proof of a visible object animation; inspect effects and test playback.
- HTML: make static content complete without JavaScript; use CSS/JS animation only as enhancement. Respect `prefers-reduced-motion`, expose keyboard controls, and prevent animations from moving reading targets continuously.
- Cross-format: don't promise animation parity when exporting between formats. Document any motion that becomes a static state.

## Static fallback

Every animated slide must communicate its full message when printed or viewed as a still. For a process, show all stages with final labels; for a reveal, make the final state readable; for a comparison, preserve baseline and result.
