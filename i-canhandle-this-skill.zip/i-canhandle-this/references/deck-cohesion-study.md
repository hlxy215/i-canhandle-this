# Whole-deck cohesion study — focused batch 2

This study compares complete JPG contact sheets, not just isolated hero slides. Sources visually inspected: `图标系列(8)`, `图标系列(12)`, `时尚风格 (24)`, `时尚风格 (48)`, `创意风格 (30)`, `创意风格 (41)`, `培训课件(20)`, and `培训课件(3)`. Six corresponding PPTX files plus `培训课件(3).pptx` were checked for slide/timing/transition markup. `培训课件(20)` is a legacy `.ppt` and was **not** checked for XML motion. This is a deeper eight-deck sample, not a claim of mastery over the collection.

## What holds each deck together

| Source | Stable visual contract | Variation that creates rhythm | Transferable technique | Do not transfer literally |
|---|---|---|---|---|
| Icon 8 | White-gray field, turquoise notebook tab, same small flat icon family, orange/turquoise/coral/purple mapping | Hub, numbered rows, arrow process, cycle, data badges | Keep icon vocabulary and color semantics stable while changing relationship geometry by message | Tiny explanatory copy, glossy shadows, watermarked preview |
| Icon 12 | White field, yellow numeric markers, brown/black type, soft edge shadows | Rising steps, connected nodes, wave path, branching vertical path | A sequential diagram family can offer many page geometries without a new visual identity | Yellow everywhere or shadows as a default modern look |
| Fashion 24 | Dark botanical photography, deep green/black, rust accents, framed portrait, large white type | Full-bleed cover, asymmetrical portrait/text, white reading panel, photo grid | Alternating dark atmospheric and light reading surfaces, with image crop and color tying them together | Fashion portraits or tiny English captions for an unrelated course |
| Fashion 48 | White field, pale-blue rectangle/square motif, black sans type, blue-toned photo | Photo-led and text-led pages alternate; occasional statistic/team/photo pages | One small geometric marker can recur across distinct layouts; accent geometry should support a strict grid | The word “fashion” or irrelevant lifestyle imagery |
| Creative 30 | City-line motif, paper-fold numerals, alternating blue/pink/red/green chapter accents | Cover → contents → numbered chapter opener → matching diagram/info pages | Use a transformed chapter identifier to connect navigation and explanation; line art anchors otherwise varied pages | Multiple section colors simultaneously on one content page; old date/title filler |
| Creative 41 | Cream field, circles in five muted hues, same clipped circle cluster as cover and section marker | Circle cluster becomes navigation, labels, timeline, chart, group diagram | A motif should perform different information roles rather than merely decorate every page | Scatter circles randomly or assume a circle conveys a relationship without labels |
| Training 20 | White field, orange teaching accent, repeated top bar/page number, subject imagery | Cover/target metaphor → section title → explanation → example/image → data/quotation | Strong teaching cadence: orient, explain, show, discuss, recap; predictable navigation | Dense paragraphs, unrelated corporate examples, tiny chart labels |
| Training 3 | Navy field, red strip and white diagram carriers, persistent page marker | Image/course opener then step, process, comparison, relationship, and summary pages | A stable high-contrast frame lets many diagram types coexist | Rainbow 3D figures, visual density, red/navy intensity for sensitive subjects |

## Combination rule: borrow functions, not skins

Do **not** concatenate raw pages from these eight decks. Choose one whole-deck contract for color, typography, margins, background treatment, icon family, photo grade, corner/stroke/shadow language, and navigation. Then borrow a *function* from another family and restyle it in that contract:

- Training supplies the **teaching order**; icon pages supply process, relationship, and comparison geometry.
- Fashion supplies **photo crop, negative space, type scale, and dark/light pacing**; it does not mandate fashion images.
- Creative supplies **one governing motif** for cover, chapters, and one or two explanatory transformations.
- An icon or diagram copied directly from another template is a source object to be recolored/retyped/refitted, not an excuse to switch the entire deck's visual identity.

Before mixing, compare six tokens: canvas ratio; background and accent roles; CJK font character; icon stroke/fill; image mood/contrast; edge/shadow treatment. If three or more visibly conflict, do not directly paste the pages together. Rebuild or restyle the borrowed structure. This is a practical review heuristic, not a mathematical score.

## Page sequence and motion decisions

For a typical instructor-led deck, draft page jobs first: opening question → objectives/roadmap → chapter marker → concept/model → worked example → learner action → feedback/recap. Each chapter should contain at least one change of carrier (e.g. diagram to case image to activity prompt), while the deck-level tokens stay stable. A flashy cover followed by twenty identical content slides is not a cohesive rhythm.

Decide motion from the speaking sequence. Reveal a process step when the instructor discusses it; reveal an answer after a learner prompt; use continuity when the same element changes state. Use a quiet cross-fade or no transition between most pages. Reserve more distinctive movement for a chapter change or meaningful transformation. The inspected PPTX files show timing/transition markup on all slides, but XML presence does not establish visible, useful animation; inspect effects and playback before reusing them.

## Acceptance test for a new deck

1. Thumbnail view: can the deck be recognized as one visual family despite varied page shapes?
2. Remove text: do backgrounds, images, icons, and diagrams still communicate each page's role, or are they decorative filler?
3. Swap pages: if any content page could be moved anywhere without hurting the teaching/story sequence, strengthen the narrative progression.
4. Projector view: are headings, diagram labels, and chart units legible at distance?
5. Play through: does each reveal occur for a stated reason, and does the static final slide still make sense?
6. Source audit: no original names, dates, watermarks, QR codes, irrelevant stock photos, or unsupported claims.
