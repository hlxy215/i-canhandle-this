# Page patterns and content mapping

| Slide job | Information shape | Starting layout | Test |
|---|---|---|---|
| Opening promise | One theme + audience/context | Large title with a single image, shape, or color field | Can the viewer infer the subject in 3 seconds? |
| Roadmap | 2–4 major chapters | Numbered list, horizontal path, or labeled grid | Does each item name a real conceptual stage? |
| Key idea | One proposition | Statement + supporting phrase + one explanatory visual | Is there exactly one takeaway? |
| Definition | Term, boundary, example | Definition on one side, concrete example on the other | Could a learner distinguish it from a neighboring concept? |
| Comparison | 2–3 alternatives on same criteria | Aligned columns or matrix with equal labels | Are comparison criteria identical and visible? |
| Process | Ordered steps / dependencies | Timeline, swimlane, or staged diagram | Is direction unambiguous? |
| Evidence | Data supporting a claim | Direct-labeled chart or photo/document with callout | Are units, source, and implication clear? |
| Case | Situation → action → result | Three-stage narrative; one strong case image if available | Are facts separated from interpretation? |
| Worked example | Show a method in use | Problem → operation → result; animate only the reasoning order | Could the audience reproduce the step? |
| Interaction | Question, task, discussion | Large prompt, time/response instruction, space for answer | Is the expected learner action explicit? |
| Synthesis | 2–4 takeaways | Short numbered statements or visual summary | Would this make sense without the presenter? |
| Closing action | One next step | Clear call to action with minimal supporting text | Is the action feasible and specific? |

## For a course deck

Plan learning objectives first, then prerequisite check, explanation, demonstration, practice, feedback, and recap. An instructor-ready deck needs teaching cues/notes and time estimates when asked; visual beauty alone is not sufficient. Use calm layouts for complex explanation, and expressive transitions only at chapter changes. Separate the learner-facing slide from notes when necessary.

## For a report deck

Lead with answer, not a long decorative agenda. Use claim-led titles (“转化率连续三月上升”) rather than generic labels (“数据分析”). Follow claim with evidence, interpretation, and decision. Preserve uncertainty where the data does not support causation.

## For an image-based reconstruction request

Identify slide region, text, geometry, image crop, and layering. Rebuild editable elements separately. Flag unknown fonts, photos, and motion; do not claim pixel-perfect or fully editable results if source pixels cannot reveal them.
