# Native page library — first four-category batch

These are eight **actual PPTX pages** extracted from four user-provided template files. They are compact reusable source material, not screenshots or rebuilt approximations. Copy a mini-deck before editing; never overwrite the library copy. The original G-drive paths below record provenance only and are not required at runtime.

| ID / source | Bundled file | Original slide numbers | Best page jobs | Required cleanup before delivery |
|---|---|---:|---|---|
| Icon relations 04 — `22-图标系列/图标系列(4).pptx` | `assets/native-pages/icon-relations-04.pptx` | 5, 8 | Four-stage process; hub-and-spoke support network | Replace all labels and advertising/filler; verify dense text and the glossy aesthetic suit the audience. |
| Fashion editorial 16 — `20-时尚风格/时尚风格 (16).pptx` | `assets/native-pages/fashion-editorial-16.pptx` | 2, 3 | Image-led opening; two-part editorial statement | Replace source photos when subject fit or rights require it; clear English filler and check headline contrast over the new image. |
| Creative line art 10 — `16-创意风格/创意风格 (10).pptx` | `assets/native-pages/creative-lineart-10.pptx` | 3, 5 | Illustrated chapter / motif continuation; three-step explanation | Page 1 retains an embedded English placeholder that ordinary text replacement does not remove. Manually cover/remove it and inspect the render. Replace city/globe imagery when irrelevant. Not ready for unattended use. |
| Training sequence 15 — `11-培训课件/培训课件(15).pptx` | `assets/native-pages/training-sequence-15.pptx` | 3, 5 | Course section opener; explanation + photo | Replace career-planning wording in slide/master/layout and the school-age photo when teaching college content. Check speaker/footer names. |

## Reuse method

1. Match **content geometry**, not merely theme: process ↔ sequence, relationships ↔ hub, photographic statement ↔ editorial page, instructional concept ↔ course page.
2. Copy the appropriate mini-deck into the job's output folder. Retain the page(s) needed; do not bring in a whole unrelated source deck.
3. Inspect slide, layout, and master layers for text. Some visible words do not appear as ordinary slide text. Remove watermarks, QR codes, source names, filler, and claims that do not belong to the new topic.
4. Replace subject-specific photos and illustrations. The bundled photos are **not** a universal image library. User authorization to reuse templates does not establish publication rights for every embedded stock asset; verify rights for public distribution.
5. Change text to fit the existing hierarchy; do not cram longer copy into it. If the subject cannot fit without breaking the composition, choose another page or build anew.
6. Render every page after editing. Inspect type, crop, contrast, leftover source material, and animation. Deliver an editable PPTX only after that visual check.

## Evidence and limits

- Each mini-deck has two slides and zero external package links, so these files can open without the G drive.
- The creative and training mini-decks contain PowerPoint timing XML; the fashion and icon mini-decks do not. The presence of timing data does **not** prove the animation looks good after editing—test it in PowerPoint.
- `assets/previews/` contains original page PNGs. The bundled native pages are source material, **not** polished final slides: image-topic mismatches and placeholders must be corrected before use.
- This is a curated eight-page seed library, not the complete 23-style collection or a guarantee that every content type has a suitable native page.
