# Icon, chart, and animation integration

This reference extends the full-deck design grammar. It distills five additional user-provided PowerPoint collections. The G-drive files are not bundled or required at runtime. If they are available and the user wants direct reuse, inspect a selected page and copy only fitting editable elements, then clear all filler and verify playback.

## Select by information relationship

| What the slide must explain | Useful construction | Icon and motion role |
| --- | --- | --- |
| Ordered process | Connected stations, restrained step bands, or a path | One recognizable action icon per step; click-to-reveal in teaching order |
| Parallel categories | Equal-sized aligned modules | One coherent icon family; reveal as a group unless discussion is sequential |
| Whole and parts | Center with satellites, nested areas, or a clear tree | Icons label components; show whole before parts |
| Comparison | Paired panels on a shared baseline | Icons only if they speed recognition; introduce baseline before contrast |
| Trend or distribution | Native chart matched to verified data | Usually omit decorative icons; build axes/units, data, then annotation |
| KPI summary | Large number with unit, denominator, period, and interpretation | Optional semantic cue; reveal one claim at a time |

Choose the relationship before the shape. An arrow asserts direction; a loop asserts recurrence; a staircase asserts ordered progression. Do not use these for unrelated parallel ideas. Keep icon stroke, fill, corner language, and optical size consistent with the receiving deck; color alone must not carry the meaning.

## Chart choice and truthfulness

Use lines for change over time, bars or dots for comparisons, and part-to-whole forms only when the parts actually total the stated whole. Record metric, unit, denominator, period, source, baseline, and any exclusions. Prefer native editable charts for real datasets. A diagram built from shapes may be editable but is not automatically a chart linked to data. If data is absent, build a labeled schematic or ask for the data. Never infer values from a template screenshot or dummy percentages. Avoid 3D depth, truncated axes, or decorative circles that distort magnitude.

## Motion as teaching choreography

Before adding an effect, write one line: “After this click, the audience can understand ___.” If no answer, leave the element static. Use a small effect vocabulary: appear/fade for progressive steps, brief emphasis for an exception, and restrained transitions at true section changes. For data, reveal scale and labels first, then series, then the conclusion without changing the scale. Preserve a readable final still. Inspect target, trigger, order, duration, and end state in PowerPoint; animation counts or timing XML alone do not prove visible, useful motion. Avoid shaking, perpetual movement, and one-click-per-decorative-object.

## Five-source study: take the logic, not the filler

| Collection | Useful observed page logic | Limit |
| --- | --- | --- |
| `图标系列(5)` | Slide 5 puts three actions into repeated arrow modules with separate descriptions. | Static icon library; heavy shadow and platform logos are not default styling. |
| `图标系列(14)` | Slides 75 and 175 use layered, numbered paths and stacked stages. | Useful for actual rank or handoff, but glossy bevel and arbitrary hierarchy should not be copied. |
| `图标系列(18)` | Slide 90 is a four-stage banner; slide 44 aligns chart series with explanatory bands; slide 54 pairs category icons with a data display. | Many slides have dense effects and dummy percentages. Simplify motion and verify values. |
| `图表 (13)` | Slide 13 combines people/money symbols for a categorical story; slide 15 aligns comparable metric modules. | Some diagrams are pictorial rather than truthful quantitative encodings. Preserve denominators and scale. |
| `图表 (16)` | Slide 8 has a strong large-number rhythm; slide 16 uses a central cluster for conceptual grouping. | Object inspection found no native charts. Do not claim its circles represent linked data. |

PowerPoint inspection found native charts on eight pages in `图标系列(18)` and five pages in `图表 (13)`; the other inspected collections were primarily shapes/icons. Effects were abundant in several sources, but their count is not a quality score. The lesson is to match topology, data encoding, and reveal order to a slide's job, then redraw or recolor them within the deck's single visual system.

## Example transfer

For a university mental-health training deck, a five-stage screening workflow can use connected stations, one action icon per stage, and click-to-reveal. A future participation-rate page needs actual school figures in an editable chart with the cohort, date, and calculation shown. The two pages may share color, typography, and icon language without sharing the same layout.
