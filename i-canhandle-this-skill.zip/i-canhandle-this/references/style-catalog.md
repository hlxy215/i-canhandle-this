# Style catalog: choose by communication job

These are archetypes distilled from observed source previews, not names of source folders. Build an original treatment using the recipe; do not paste a complete source slide.

| Grammar | Use when | Palette / type | Composition / motif | Avoid |
|---|---|---|---|---|
| Quiet editorial | Reflective, human, cultural, premium, story-led | Warm white or soft gray; charcoal; muted sage/blue/rose; restrained serif display + clear sans body | Asymmetric headline, generous margins, one cropped image, thin lines, subtle paper/watercolor field | Tiny low-contrast copy, decorative flourishes on every slide |
| Precision minimal | Strategy, thesis, product concept, executive talk | White/ink plus one accent | Strong grid, large statement, sparse geometry, disciplined labels | Mistaking emptiness for clarity; no evidence |
| Geometric business | Proposal, company intro, project update | Light neutral + confident teal/blue/orange or user brand | Large corner/edge shape on cover; clean cards, process arrows, native charts | Heavy gradient ribbons, repeated chrome effects, clip-art teams |
| Evidence analytical | Finance, operations, research result | Mostly white/ink; one data highlight hue | Insight headline, aligned chart/table, direct annotation, comparable scales | Decorative gauges, invented values, dense infographic wallpaper |
| Learning studio | Classroom or training with active participation | Calm neutral base, friendly accent pair | Worked example, question, answer reveal, exercise prompt, diagram in stages | Childlike illustrations for adult learners; decorative footer taking content area |
| Botanical / cultural | Literature, wellness, heritage, contemplative subjects | Ink, cream, sage or soft blossom accent | Controlled botanical/ink element, vertical micro-label, textured cover only | Cultural clichés, faux calligraphy in body text, excessive texture |
| Photo-led magazine | Fashion, portfolio, person/story, product mood | Palette sampled from photography; high-contrast ink | Bold crop, staggered image sizes, generous editorial spacing | Unlicensed imagery; fashionable but unreadable captions |
| Kinetic typography | Opening sting, event countdown, short announcement | Two high-contrast colors | One phrase or number per beat, abrupt but intentional rhythm, no dense body | Applying flash/rapid cuts to information slides or accessibility-critical content |

## Combination rules

- Choose one grammar as the backbone. Borrow only a component from a second grammar: e.g. Precision minimal grid + one Botanical accent, or Evidence analytical chart treatment + Photo-led cover.
- Do not use a source folder as a topic filter. The sampled “工作汇报” folder contains both light infographics and dramatic red cinematic covers; “创意风格” spans 3D ribbons and pencil line art. “快闪风格” includes dark glitch treatment and plain blue/white kinetic text. Audience and content decide, not the folder label.
- Match emotional intensity to stakes: a medical or educational talk should generally prioritize credibility and calm over spectacle, even if a dramatic template exists.

## Design tokens to define before production

Record: canvas ratio; background/ink/accent/highlight colors; Chinese and Latin font fallbacks; title/body/label sizes; outer margin and columns; corner radius/stroke style; photo treatment; repeating motif; transition style; chart color rules. Keep this specification in the project so PPTX and HTML versions can stay aligned.
