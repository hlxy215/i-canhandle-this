# Extending an existing branded slide template

Read this when the user asks to expand a company/official PPTX into a reusable slide system. The goal is a coherent **menu of working layouts**, not more pages for their own sake. The original deck is evidence of the brand; it is not permission to keep irrelevant filler or to claim new editability for raster artwork.

## Establish the brand contract

Inspect representative original pages (cover, section, dense content, image, and data page if present), the theme/master, and object types. Record what stays stable: canvas, logo placement and safe area, Chinese/Latin font fallbacks, color **roles** rather than just swatches, margins/grid, corner and line treatment, photo grade/crop, chart colors, and navigation. Preserve the source's content and visual identity unless the user requests a redesign. If the source is inconsistent, resolve the inconsistency into a small token set and identify the change.

Decide which product the user actually needs:

| Deliverable | What it supports | What to verify |
| --- | --- | --- |
| Editable example deck | Copy a finished page and replace its native objects | New text, shapes, pictures, and charts are selectable and editable |
| PowerPoint theme/Slide Master layouts | Consistent layout application to future slides | A new slide can use the intended master/layout, not just mimic a sample page |
| Native picture placeholders | Insert/replace an image through a layout's picture slot | The slot is a genuine PowerPoint placeholder and accepts a test image |

An ordinary rectangle marked “放图片”, or an existing picture object, can be a useful photo area but is **not** a Slide Master picture placeholder. Do not call it one-click insertion. State plainly when users must insert or replace a picture manually. Likewise, editable shapes that resemble a chart are not a data-linked native chart.

## Build a chapter system, not isolated covers

Derive the number and names of major chapters from the material or the user's explicit request. Do not hard-code eight chapters because one project used 01–08. For each real chapter, keep the numeral format, title hierarchy, grid, motif language, and logo/navigation position stable. Vary one or two controlled dimensions—photo placement, background light/dark role, motif crop/scale, or text-image balance—across a small set of related compositions. Avoid eight unrelated skins or the same page with only the number changed. Variants must still read as one company deck in thumbnail view.

Check the chapter list, dividers, running labels, and recap/navigation pages against one sequence. The number of section pages, their 01…n labels, and the contents page must agree. Keep numerals and titles as editable text where promised. Do not claim automatic renumbering unless the file actually implements it.

Treat number-plus-arrow or number-plus-line devices as aligned components: define a shared centerline/anchor, keep equal optical spacing, and inspect them at 100% and in a rendered contact sheet. Geometric centering can still look off when numeral shapes, arrowheads, or unequal line weights shift visual mass; adjust optically, then recheck all repeated instances.

## Choose photo layouts by communication job

Offer only the image compositions the future content will use. A practical menu can include a single hero with text-safe negative space, a portrait-plus-quote or speaker page, a two-image comparison, a three-frame story/process, an annotated case photograph, and a small equal-cell gallery. These are options, not a mandatory six-page quota. Assign every slot an intended aspect ratio, subject-safe area, crop behavior, caption/source position, and replacement method.

Use **crop to fill**, not stretch, and test at least one portrait and one landscape replacement in representative slots. Reposition the crop around faces, hands, products, or evidence; a technically filled slot is not successful if the subject is cut off or text loses contrast. Reserve adequate room for captions and permissions. Use user-supplied or licensed pictures, and keep brand color grading coherent without making clinical or documentary images misleading.

## Make data pages usable later

Include a data-ready layout when the brief anticipates future metrics, but select the chart form from the relationship: bars/dots for category comparison, line for time change, a direct-labeled part-to-whole only when the total is valid, or a relationship diagram for non-quantitative structure. Do not add chart types merely to display variety. Pair the chart with an insight title and places for unit, denominator, period, source, and interpretation.

For a native editable chart, verify that its embedded data can be changed in PowerPoint and the visual updates. If the data is not supplied, leave a clearly labeled empty schematic or visibly mark any sample numbers as **示例数据／发布前替换**; never let dummy figures read as company results. A shape-based infographic may be a useful editable diagram, but it must not be described as an editable data chart.

Animation follows the speaking sequence, not the template's effect count. A restrained chapter transition or step reveal may help; inherited animation must be inspected for target, trigger, order, and final still. Keep static pages complete for printing and export.

## Acceptance checks

1. Compare original and expanded decks: source pages remain intact unless changes were requested; no source debris, placeholder company claims, or unexplained style switch.
2. Check chapter count/order, contents, labels, and each controlled variant. In thumbnail view, the deck is one family with visible rhythm.
3. Replace sample photos in each distinct slot type; check aspect ratio, focal crop, text safety, caption, and whether the promised replacement method really works.
4. Change values in each promised native chart type; verify labels, units, scale, source fields, and visual response. If there is no real data, confirm conspicuous sample labeling.
5. Render every page at presentation size. Inspect overflow, image crop, contrast, logo clearance, and repeated alignments—including centered numerals, arrows, and connector endpoints. Play through any retained animation and inspect its static final state.
