# Native page library

The first four mini-decks contain eight **actual PPTX pages** extracted from user-provided templates. A later diagram batch adds one complete 30-page icon deck and two selected data-diagram pages. These are reusable sources, not finished slides. Copy before editing; never overwrite the library copy. The original G-drive paths record provenance only and are not required at runtime.

| ID / source | Bundled file | Original slide numbers | Best page jobs | Required cleanup before delivery |
|---|---|---:|---|---|
| Icon relations 04 — `22-图标系列/图标系列(4).pptx` | `assets/native-pages/icon-relations-04.pptx` | 5, 8 | Four-stage process; hub-and-spoke support network | Replace all labels and advertising/filler; verify dense text and the glossy aesthetic suit the audience. |
| Fashion editorial 16 — `20-时尚风格/时尚风格 (16).pptx` | `assets/native-pages/fashion-editorial-16.pptx` | 2, 3 | Image-led opening; two-part editorial statement | Replace source photos when subject fit or rights require it; clear English filler and check headline contrast over the new image. |
| Creative line art 10 — `16-创意风格/创意风格 (10).pptx` | `assets/native-pages/creative-lineart-10.pptx` | 3, 5 | Illustrated chapter / motif continuation; three-step explanation | Page 1 retains an embedded English placeholder that ordinary text replacement does not remove. Manually cover/remove it and inspect the render. Replace city/globe imagery when irrelevant. Not ready for unattended use. |
| Training sequence 15 — `11-培训课件/培训课件(15).pptx` | `assets/native-pages/training-sequence-15.pptx` | 3, 5 | Course section opener; explanation + photo | Replace career-planning wording in slide/master/layout and the school-age photo when teaching college content. Check speaker/footer names. |
| Diagram icon5 — `22-图标系列/图标系列(5).pptx` | `assets/native-pages/diagram-icon5-30.pptx` | 1–30, original order | Distinct parallel, progressive, hierarchical, radial and percentage-themed variants; see `diagram-variant-catalog.md` for per-page IDs | Replace all GK design advertising, platform logos, placeholder percentages and copy; simplify dated gradients/shadows when required. Percentage-themed pages are not automatically valid data charts. |
| Data diagram13 — `23图表风格/图表 (13).pptx` | `assets/native-pages/data-chart13-selected.pptx` | Original 13, 15 → bundled 1, 2 | Pictorial four-category diagram; four radial KPI modules | Remove English filler and recalculate all values, denominators, and arc lengths. Verify editability and visual encoding. |

## Reuse method

1. Match **content geometry**, not merely theme: process ↔ sequence, relationships ↔ hub, photographic statement ↔ editorial page, instructional concept ↔ course page.
2. Copy the appropriate mini-deck into the job's output folder. Retain the page(s) needed; do not bring in a whole unrelated source deck.
3. Inspect slide, layout, and master layers for text. Some visible words do not appear as ordinary slide text. Remove watermarks, QR codes, source names, filler, and claims that do not belong to the new topic.
4. Replace subject-specific photos and illustrations. The bundled photos are **not** a universal image library. User authorization to reuse templates does not establish publication rights for every embedded stock asset; verify rights for public distribution.
5. Change text to fit the existing hierarchy; do not cram longer copy into it. For box-and-line diagrams, if the content cannot fit without breaking proportions or connectors, choose another complete page or switch to a connector-free layout. Do not rebuild a near-match by drawing curves around the text.
6. Render every page after editing. Inspect type, crop, contrast, leftover source material, and animation. Deliver an editable PPTX only after that visual check.

## Evidence and limits

- The first four mini-decks each have two slides; the added icon deck has 30, and the added data diagram mini-deck has two. They open without the G drive.
- The creative and training mini-decks contain PowerPoint timing XML; the fashion and icon mini-decks do not. The presence of timing data does **not** prove the animation looks good after editing—test it in PowerPoint.
- In the added diagram batch, all 30 icon pages have zero PowerPoint main-sequence effects and no entry transition. The two data-diagram pages have 18 effects each, all simultaneous 0.7-second triggers; neither is a ready-made step-by-step teaching reveal. Rebuild motion when the speaking sequence calls for it.
- `assets/previews/` contains original page PNGs. The bundled native pages are source material, **not** polished final slides: image-topic mismatches and placeholders must be corrected before use.
- The native assets are a curated portable subset, not the complete 23-style collection or a guarantee that every content type has a suitable original page. The full source/deck index is in `references/library-index/`; unreviewed entries are not direct-reuse promises.
