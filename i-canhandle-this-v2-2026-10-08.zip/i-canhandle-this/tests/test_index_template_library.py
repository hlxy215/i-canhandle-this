import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from index_template_library import build  # noqa: E402


def slide_xml(title: str) -> str:
    return (
        '<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        f"<p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>{escape(title)}</a:t>"
        "</a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>"
    )


class IndexLibraryTests(unittest.TestCase):
    def test_same_name_pages_remain_distinct(self):
        # Catches accidental de-duplication by diagram label.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "source"
            folder = root / "22-图标系列"
            folder.mkdir(parents=True)
            with zipfile.ZipFile(folder / "图标系列(5).pptx", "w") as zf:
                zf.writestr("ppt/slides/slide2.xml", slide_xml("四项并列关系图表"))
                zf.writestr("ppt/slides/slide3.xml", slide_xml("四项并列关系图表"))
            output = Path(tmp) / "index"
            build(root, output)
            rows = [json.loads(line) for line in
                    (output / "diagram-slide-index.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual(["icon05-s002", "icon05-s003"], [row["id"] for row in rows])
            self.assertEqual(2, len({row["id"] for row in rows}))
            self.assertEqual(["四项并列关系图表"] * 2, [row["label"] for row in rows])
            self.assertTrue(all(row["visual_review"] == "not_reviewed" for row in rows))


if __name__ == "__main__":
    unittest.main()
