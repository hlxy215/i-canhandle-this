---
name: i-canhandle-this
description: Use when creating or redesigning editable PPTX or offline HTML presentations, including branded company templates, courseware, reports, proposals, data-rich slides, icon-based diagrams, and animated teaching decks, with or without a source deck.
---

# 交给我吧（i canhandle this）

This skill is portable. The original G-drive collection is **not** a runtime dependency. It contains a searchable source index, visually reviewed diagram variants, and a small user-authorized library of native editable pages in `assets/native-pages/`. The index is **not** a claim that every source page has been visually studied or bundled. Read `references/template-retrieval.md` when retrieving a template and `references/native-page-library.md` before direct reuse.

## Intake and decision

1. Determine the audience, presentation setting, purpose, desired duration/slide count, content, delivery format (PPTX, HTML, or both), and editability expectations. If missing, infer a conservative default and state it briefly. Ask only if the missing choice changes the result materially.
2. Convert the material into a message arc before drawing slides: opening promise → context/problem → 2–4 idea blocks → evidence/demo/exercise → takeaway/action. For a course, add learning objectives, concept explanation, worked example, learner interaction, recap. Do not force a business-report outline onto teaching.
3. Assign each slide one **job** and one sentence-level takeaway. Pick layouts from `references/page-patterns.md` according to information shape, not by alternating arbitrary templates.
4. If extending an existing branded deck, read `references/brand-template-expansion.md` first and treat its observed brand contract as the base grammar; do not apply a new skin over it. Otherwise, choose a grammar from `references/style-catalog.md` using audience, emotional tone, and content density. Combine at most two compatible grammars. Set palette, type pairing, grid, image treatment, icon language, and recurring motif before slide generation.
   For a multi-slide deck, read `references/deck-cohesion-study.md` and borrow functions across template families without importing conflicting skins.
   Deck cohesion does not mean making every diagram look alike. Preserve purposeful variety in complete source compositions—their spatial structure, icon treatment, depth, and accent colors—when the slide jobs differ. Harmonize typography and overall color relationships without flattening distinctive diagrams into one repeated card or curve style.
5. Use `references/design-grammar.md` for geometry, typographic hierarchy, and pacing. When the content involves processes, categories, numbers, or data, read `references/template-retrieval.md`, then `references/diagram-variant-catalog.md` for visually verified candidates and `references/icon-chart-motion.md` for chart and animation choices. Search the page-level index when more variants are needed. Repeated source labels are distinct designs, not duplicates. Use `references/motion.md` for format-specific motion decisions.
6. Before rendering, complete the **visual carrier** plan in `references/visual-completion.md`: every slide needs a background role, a primary visual carrier, and a content-to-visual mapping. A sound outline with uniform pale backgrounds and text columns is not an acceptable finished deck.
7. For box-and-line visuals (branching, convergence, hierarchy, paths, framed relationships), **select an intact, visually checked native composition** from the bundled pages or an accessible source library before producing the slide. Match topology, item count, reading order, and text capacity; copy the source page and replace content in-place. Preserve its geometry, connector routing, and proportions while adapting typography and palette. If no complete source fits, choose a connector-free layout or identify the missing template; do not improvise a similar-looking network of curves and boxes. Verify any inherited animation before use.

## Production rules

- Prefer native editable text, shapes, and charts in PPTX. In HTML, keep the deck self-contained/offline, responsive to a 16:9 stage, keyboard-navigable, and printable/exportable where feasible. If both formats are requested, use one shared design specification and check parity.
- For a reusable PPTX, distinguish editable sample slides, actual Slide Master/layouts, native picture placeholders, and ordinary picture objects or drawn frames. Promise only the kind of reuse and replacement that the file actually supports.
- Treat every icon, chart, and motion effect as part of the explanation. Icons should encode actions or categories consistently; real data charts must retain verified values, units, denominator, period, and source. Do not turn template filler numbers into claims. Animation should reveal the speaker's reasoning while leaving a complete static state.
- Build slides from content outward. A slide is not finished when the placeholders are filled; rewrite, split, or omit material to preserve reading hierarchy.
- Use the four focused recipes in `references/focus-collections.md` when the brief calls for a stronger design: icon/infographic systems, fashion-editorial art direction, creative motif systems, and instructor-led courseware. Prefer a small coherent element vocabulary over adding unrelated decoration.
- Use genuine user-provided or licensed visual assets. Never transfer previews' QR codes, advertising overlays, watermarks, placeholder dates/names, random logos, stock claims, or decorative English filler.
- For a user-authorized template reuse request, direct reuse of a bundled native page is allowed. Remove source branding, placeholder copy, inappropriate photos, and irrelevant visual claims before handoff. Original layouts remain appropriate for typography, imagery, and accurate data charts; the box-and-line selection rule above takes precedence for relationship diagrams.
- If source is an image, distinguish visual reconstruction from editable reconstruction. Explain what can be made native and what remains raster; do not promise perfect recovery from pixels.
- For animation, provide a static fallback and honor reduced-motion preference in HTML. Avoid autoplay motion that shakes, distracts, or conceals important content.

## Internal pre-handoff checks

Check every slide for: claim accuracy and source handling; legibility at presentation distance; consistent alignment and spacing; intentional contrast; text overflow and crop; chart labels and units; image rights/provenance; motion that adds meaning; no source debris; editable elements as promised. Across the deck, check that different information shapes use suitably varied diagram families and accent colors rather than one repeated template. For selected box-and-line diagrams, compare the rendered result with the source for complete shapes, intact endpoints, undistorted proportions, and consistent connector weight. For a reusable template, also verify chapter navigation, photo replacement, chart data editing, and number/arrow centering against the delivered file. Render or inspect the output before claiming completion. User acceptance is a separate stage—do not impersonate the user's validation.

## Reference routing

- Core visual and information design: `references/design-grammar.md`
- Style selection and combination: `references/style-catalog.md`
- Slide jobs, content-to-layout mapping: `references/page-patterns.md`
- PPTX/HTML animation and static alternatives: `references/motion.md`
- Evidence, sample coverage, and limits of this study: `references/study-notes.md`
- Required visual-carrier plan and visual QA: `references/visual-completion.md`
- Focused icon, fashion, creative, and training recipes: `references/focus-collections.md`
- Bundled native pages, provenance, fit, cleanup, and limits: `references/native-page-library.md`
- Whole-deck rhythm, safe mixing, and motion decisions from eight additional samples: `references/deck-cohesion-study.md`
- Extending an existing branded/company template with chapter systems, image slots, and data-ready pages: `references/brand-template-expansion.md`
- Integrated icon, data-chart, and animation decisions from five further samples: `references/icon-chart-motion.md`
- Indexed template memory and retrieval limits: `references/template-retrieval.md`
- Visually checked, non-deduplicated diagram variants: `references/diagram-variant-catalog.md`
- Professional design vocabulary and copy-ready instructions: `references/professional-directives.md`
