#!/usr/bin/env python3
"""Index the user's PPTX library without copying the source decks.

Build: python index_template_library.py build SOURCE_ROOT OUTPUT_DIR
Find:  python index_template_library.py find OUTPUT_DIR KEYWORD [--kind slide|deck]

The checked-in indexes use relative source paths. A matching source collection is
optional at runtime; the index remains searchable on another computer.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


SLIDE_RE = re.compile(r"^ppt/slides/slide(\d+)\.xml$")
TEXT = "{http://schemas.openxmlformats.org/drawingml/2006/main}t"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
SEMANTIC = ("并列", "递进", "层级", "循环", "联动", "发散", "聚合", "对比", "关系", "百分比")


def variant_id(category: str, deck: str, slide: int) -> str:
    nums = re.findall(r"\d+", deck)
    deck_num = int(nums[-1]) if nums else 0
    prefix = "icon" if "图标" in category else "chart"
    return f"{prefix}{deck_num:02d}-s{slide:03d}"


def slide_record(zf: zipfile.ZipFile, member: str, category: str, deck: str, relpath: str) -> dict:
    number = int(SLIDE_RE.match(member).group(1))
    root = ET.fromstring(zf.read(member))
    texts = [node.text.strip() for node in root.iter(TEXT) if node.text and node.text.strip()]
    labels = [value for value in texts if any(term in value for term in SEMANTIC)]
    return {
        "id": variant_id(category, deck, number),
        "source": relpath,
        "slide": number,
        "label": labels[-1] if labels else "",
        "all_labels": labels,
        "text_excerpt": " / ".join(texts[:8])[:160],
        "shapes": sum(1 for el in root.iter(P + "sp")),
        "pictures": sum(1 for el in root.iter(P + "pic")),
        "native_charts": sum(1 for el in root.iter(C + "chart")),
        "timing_xml": any(el.tag == P + "timing" for el in root.iter()),
        "transition_xml": any(el.tag == P + "transition" for el in root.iter()),
        "visual_review": "not_reviewed",
    }


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def build(source: Path, output: Path) -> None:
    decks = []
    slides = []
    errors = []
    for path in sorted(source.rglob("*.pptx")):
        relpath = path.relative_to(source).as_posix()
        category = path.parent.name
        try:
            with zipfile.ZipFile(path) as zf:
                members = [m for m in zf.namelist() if SLIDE_RE.match(m)]
                decks.append({
                    "source": relpath,
                    "category": category,
                    "preview": path.with_suffix(".jpg").relative_to(source).as_posix()
                    if path.with_suffix(".jpg").exists() else None,
                    "slides": len(members),
                    "size_bytes": path.stat().st_size,
                })
                if category.startswith("22-") or category.startswith("23"):
                    for member in members:
                        slides.append(slide_record(zf, member, category, path.name, relpath))
        except (OSError, zipfile.BadZipFile, ET.ParseError) as exc:
            errors.append({"source": relpath, "error": str(exc)[:200]})
    slides.sort(key=lambda r: (r["source"], r["slide"]))
    write_jsonl(output / "deck-index.jsonl", decks)
    write_jsonl(output / "diagram-slide-index.jsonl", slides)
    write_jsonl(output / "index-errors.jsonl", errors)
    print(json.dumps({"decks": len(decks), "diagram_slides": len(slides), "errors": len(errors)}, ensure_ascii=False))


def find(output: Path, keyword: str, kind: str) -> None:
    filename = "diagram-slide-index.jsonl" if kind == "slide" else "deck-index.jsonl"
    hits = 0
    with (output / filename).open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if keyword.casefold() in json.dumps(row, ensure_ascii=False).casefold():
                print(json.dumps(row, ensure_ascii=False))
                hits += 1
    print(f"{hits} matches", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p_build = sub.add_parser("build")
    p_build.add_argument("source", type=Path)
    p_build.add_argument("output", type=Path)
    p_find = sub.add_parser("find")
    p_find.add_argument("output", type=Path)
    p_find.add_argument("keyword")
    p_find.add_argument("--kind", choices=("slide", "deck"), default="slide")
    args = parser.parse_args()
    if args.command == "build":
        build(args.source, args.output)
    else:
        find(args.output, args.keyword, args.kind)


if __name__ == "__main__":
    main()
